#ifndef BOARD_H
#define BOARD_H

#include <QWidget>
#include "Stone.h"

class Board : public QWidget
{
    Q_OBJECT
public:
    explicit Board(QWidget *parent = nullptr);

    Stone _s[32];
    int _r;//棋子的半径
    int _selectid;
    bool _bRedTurn;

    QPoint center(int row,int col);//返回象棋棋盘行列对应的像素坐标
    QPoint center(int id);

    bool getRowCol(QPoint pt,int& row,int& col);

    void drawStone(QPainter& painter, int id);

    void paintEvent(QPaintEvent *);

    void mouseReleaseEvent(QMouseEvent *);//鼠标走棋

    bool canMove(int moveid,int row,int col,int killid);
    bool canMoveJIANG(int moveid,int row,int col,int killid);
    bool canMoveSHI(int moveid,int row,int col,int killid);
    bool canMoveXIANG(int moveid,int row,int col,int killid);
    bool canMoveMA(int moveid,int row,int col,int killid);
    bool canMoveCHE(int moveid,int row,int col,int killid);
    bool canMovePAO(int moveid,int row,int col,int killid);
    bool canMoveBING(int moveid,int row,int col,int killid);

signals:

public slots:
};

#endif // BOARD_H
