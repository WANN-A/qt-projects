#include "Stone.h"

Stone::Stone()
{

}
