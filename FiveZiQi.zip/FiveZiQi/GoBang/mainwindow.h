#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QPainter"
#include "QPaintEvent"//绘画事件
#include "QMouseEvent"//鼠标事件
#include "QVector"
#include "QMessageBox"
#include "chessitem.h"

/*
QT的2D绘画
*/

#define CHESS_R  15
#define CHESS_C  15
#define MAX_X    50
#define MAX_Y    50


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event);//实时绘制界面
    void mousePressEvent(QMouseEvent *event);//鼠标点击事件

private:
    void InitUI();//初始化界面
    void DrawChessBoard();//画棋盘
    void DrawHandChess();//画鼠标上的棋子
    void DrawChessItem();//绘制棋盘上的棋子
    void DrawChessAtPoint(QPainter &painter,QPoint &point);//画棋子的样式和位置
    int CountNearItem(ChessItem item,QPoint pt);//判断棋子是否五子连接

private:
    Ui::MainWindow *ui;
    bool b_black;//定义棋子的颜色
    QVector<ChessItem> p_ChessItem;//定义棋子个数



};

#endif // MAINWINDOW_H
